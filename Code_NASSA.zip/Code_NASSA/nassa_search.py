import os
import sys
import time
import glob
import gc
import numpy as np
import utils
import logging
import argparse
import torch.utils
import torch.nn.functional as F
import torchvision.datasets as dset
import torch.backends.cudnn as cudnn
from model_search import Network
from operations import *
from torch.autograd import Variable
from genotypes import PRIMITIVES
from genotypes import Genotype

parser = argparse.ArgumentParser("cifar")
parser.add_argument('--data', type=str, default='./data', help='location of the data corpus')
parser.add_argument('--batch_size', type=int, default=32, help='batch size')
parser.add_argument('--report_freq', type=float, default=50, help='report frequency')
parser.add_argument('--gpu', type=int, default=0, help='gpu device id')
parser.add_argument('--init_channels', type=int, default=16, help='num of init channels')
parser.add_argument('--layers', type=int, default=8, help='total number of layers')
parser.add_argument('--cutout', action='store_true', default=False, help='use cutout')
parser.add_argument('--save', type=str, default='EXP', help='experiment name')
parser.add_argument('--seed', type=int, default=0, help='random seed')
parser.add_argument('--NASSA', action = 'store_true', default=True, help='NASSA or NASSA_FOHD')
parser.add_argument('--train_portion', type=float, default=0.5, help='portion of training data')
parser.add_argument('--pretrain_path', type=str, default=None, help='load the path of pretrain')

args = parser.parse_args()


args.save = 'exp/nassa-search-{}-{}'.format(args.save, time.strftime("%Y%m%d-%H%M%S"))
utils.create_exp_dir(args.save, scripts_to_save=glob.glob('*.py'))

log_format = '%(asctime)s %(message)s'
logging.basicConfig(stream=sys.stdout, level=logging.INFO,
                    format=log_format, datefmt='%m/%d %I:%M:%S %p')
fh = logging.FileHandler(os.path.join(args.save, 'log.txt'))
fh.setFormatter(logging.Formatter(log_format))
logging.getLogger().addHandler(fh)

CIFAR_CLASSES = 10

def main():
    if not torch.cuda.is_available():
        logging.info('no gpu device available')
        sys.exit(1)

    np.random.seed(args.seed)

    torch.cuda.set_device(args.gpu)

    cudnn.benchmark = True
    torch.manual_seed(args.seed)
    cudnn.enabled = True
    torch.cuda.manual_seed(args.seed)

    logging.info('gpu device = %d' % args.gpu)
    logging.info("args = %s", args)

    criterion = nn.CrossEntropyLoss()
    criterion = criterion.cuda(args.gpu)

    model = Network(args.init_channels, CIFAR_CLASSES, args.layers, criterion, args.gpu)

    model.load_state_dict(torch.load(args.pretrain_path +'/weights.pt'))

    model = model.cuda(args.gpu)

    logging.info("param size = %fMB", utils.count_parameters_in_MB(model))
    n, r = torch.load(args.pretrain_path +'/alpha.pt')
    n = F.softmax(n.cuda(args.gpu), dim=-1)
    r = F.softmax(r.cuda(args.gpu), dim=-1)

    model.alphas_normal = n.data
    model.alphas_normal.requires_grad = True
    model.alphas_reduce = r.data
    model.alphas_reduce.requires_grad = True
    model._arch_parameters = [
            model.alphas_normal,
            model.alphas_reduce,
    ]

    train_transform, valid_transform = utils._data_transforms_cifar10(args)
    train_data = dset.CIFAR10(root=args.data, train=True, download=False, transform=train_transform)

    num_train = len(train_data)
    indices = list(range(num_train))
    split = int(np.floor(args.train_portion * num_train))

    valid_queue = torch.utils.data.DataLoader(
        train_data, batch_size=args.batch_size,
        sampler=torch.utils.data.sampler.SubsetRandomSampler(indices[split:]),
        pin_memory=True, num_workers=0)

    theta_normal = 0.0
    theta_reduce = 0.0
    # architecture search
    theta_normal, theta_reduce = architecture_search(valid_queue, model, theta_normal, theta_reduce)
    # architecture selection
    gene_normal = _parse(theta_normal.data.cpu().numpy())
    gene_reduce = _parse(theta_reduce.data.cpu().numpy())
    concat = [2, 3, 4, 5]
    genotype = Genotype(
        normal=gene_normal, normal_concat=concat,
        reduce=gene_reduce, reduce_concat=concat
    )
    print(genotype)


def architecture_search(valid_queue, model, theta_normal, theta_reduce):

    for step, (input, target) in enumerate(valid_queue):
        print('|----------------   step = %d  -------------------------|\n'% step)

        input = Variable(input, requires_grad=True).cuda(args.gpu)
        target = Variable(target, requires_grad=False).cuda(args.gpu)

        # accumulate the gradients
        loss = model._loss(input, target)
        grad_params = torch.autograd.grad(loss, model._arch_parameters, create_graph=True)

        normal_first_grad = grad_params[0]
        reduce_first_grad = grad_params[1]
        # compute the the sum of gradients
        if args.NASSA:
            grad_sum = 0
            for (grad, params) in zip(grad_params, model._arch_parameters):
                grad_sum += (grad * (params.detach())).sum()
            # back propogate the first order gradient.
            grad_sum.backward()
            # obtain the second order gradient
            normal_second_grad = model.alphas_normal.grad
            reduce_second_grad = model.alphas_reduce.grad

            theta_normal += (- normal_first_grad * model.alphas_normal + 0.5 * normal_second_grad * (model.alphas_normal).pow(2)).pow(2)
            theta_reduce += (- reduce_first_grad * model.alphas_reduce + 0.5 * reduce_second_grad * (model.alphas_reduce).pow(2)).pow(2)
        else:
            theta_normal += (- normal_first_grad * model.alphas_normal + 0.5 * normal_first_grad.pow(2) * (model.alphas_normal).pow(2)).pow(2)
            theta_reduce += (- reduce_first_grad * model.alphas_reduce + 0.5 * reduce_first_grad.pow(2) * (model.alphas_reduce).pow(2)).pow(2)


        logging.info('saliency of normal cell: %s',format(str(theta_normal)))
        logging.info('saliency of reduction cell: %s',format(str(theta_reduce)))
        gene_normal = _parse(theta_normal.data.cpu().numpy())
        gene_reduce = _parse(theta_reduce.data.cpu().numpy())
        concat = [2, 3, 4, 5]
        genotype = Genotype(
            normal=gene_normal, normal_concat=concat,
            reduce=gene_reduce, reduce_concat=concat
        )
        print(genotype)

        # clear cache
        del input
        del target
        del grad_params
        gc.collect()

    print('saliency:', theta_normal, theta_reduce)
    theta_normal = theta_normal / (step + 1)
    theta_reduce = theta_reduce / (step + 1)
    print('normalized saliency:', theta_normal, theta_reduce)
    return theta_normal, theta_reduce

def _parse(weights):
    gene = []
    n = 2
    start = 0
    for i in range(4):
        end = start + n
        W = weights[start:end].copy()
        edges = sorted(range(i + 2),
                       key=lambda x: -max(W[x][k] for k in range(len(W[x])) if k != PRIMITIVES.index('none')))[
                :2]
        for j in edges:
            k_best = None
            for k in range(len(W[j])):
                if k != PRIMITIVES.index('none'):
                    if k_best is None or W[j][k] > W[j][k_best]:
                        k_best = k
            gene.append((PRIMITIVES[k_best], j))
        start = end
        n += 1
    return gene


if __name__ == '__main__':
    main()
