import os
import sys
import time
import glob
import numpy as np
import torch
import utils
import logging
import argparse
import torch.nn as nn
import torch.utils
import torch.nn.functional as F
import torchvision.datasets as dset
import torch.backends.cudnn as cudnn

from torch.autograd import Variable
from model_search import Network
from architect import Architect
from tensorboardX import SummaryWriter

parser = argparse.ArgumentParser("cifar")
parser.add_argument('--data', type=str, default='../../../../data', help='location of the data corpus')
parser.add_argument('--batch_size', type=int, default=16, help='batch size')
parser.add_argument('--learning_rate', type=float, default=0.025, help='init learning rate')
parser.add_argument('--learning_rate_min', type=float, default=0.001, help='min learning rate')
parser.add_argument('--momentum', type=float, default=0.9, help='momentum')
parser.add_argument('--weight_decay', type=float, default=3e-4, help='weight decay')
parser.add_argument('--report_freq', type=float, default=50, help='report frequency')
parser.add_argument('--gpu', type=int, default=0, help='gpu device id')
parser.add_argument('--epochs', type=int, default=50, help='num of training epochs')
parser.add_argument('--init_channels', type=int, default=16, help='num of init channels')
parser.add_argument('--layers', type=int, default=8, help='total number of layers')
parser.add_argument('--model_path', type=str, default='saved_models', help='path to save the model')
parser.add_argument('--cutout', action='store_true', default=False, help='use cutout')
parser.add_argument('--cutout_length', type=int, default=16, help='cutout length')
parser.add_argument('--drop_path_prob', type=float, default=0.3, help='drop path probability')
parser.add_argument('--save', type=str, default='EXP-CIFAR100', help='experiment name')
parser.add_argument('--seed', type=int, default=0, help='random seed')
parser.add_argument('--grad_clip', type=float, default=5, help='gradient clipping')
parser.add_argument('--train_portion', type=float, default=0.5, help='portion of training data')
parser.add_argument('--unrolled', action='store_true', default=True, help='use one-step unrolled validation loss')
parser.add_argument('--arch_learning_rate', type=float, default=3e-4, help='learning rate for arch encoding')
parser.add_argument('--arch_weight_decay', type=float, default=1e-3, help='weight decay for arch encoding')
args = parser.parse_args()

# 创建保存实验结果的文件夹,并将当前文件夹下的所有的.py的文件复制到实验结果的文件夹下
args.save = 'search-{}-{}'.format(args.save, time.strftime("%Y%m%d-%H%M%S"))
utils.create_exp_dir(args.save, scripts_to_save=glob.glob('*.py'))

log_format = '%(asctime)s %(message)s'
logging.basicConfig(stream=sys.stdout, level=logging.INFO,
                    format=log_format, datefmt='%m/%d %I:%M:%S %p')
fh = logging.FileHandler(os.path.join(args.save, 'log.txt'))
fh.setFormatter(logging.Formatter(log_format))
logging.getLogger().addHandler(fh)

CIFAR_CLASSES = 10


def main(train_queue, valid_queue):
    if not torch.cuda.is_available():
        logging.info('no gpu device available')
        sys.exit(1)

    np.random.seed(args.seed)
    # 设置索要使用的gpu
    torch.cuda.set_device(args.gpu)
    # 在程序刚开始加这条语句可以提升一点训练速度
    cudnn.benchmark = True
    torch.manual_seed(args.seed)
    cudnn.enabled = True
    torch.cuda.manual_seed(args.seed)
    # 向log文件里面写入一些参数信息
    logging.info('gpu device = %d' % args.gpu)
    logging.info("args = %s", args)
    args.pretrain_path = '../'
    # 　设置损失函数为交叉熵损失函数
    criterion = nn.CrossEntropyLoss()
    criterion = criterion.cuda()
    # 初始化网络结构，传入的参数为网络输入的通道16，输出的通道10，网络的层数8，损失函数　
    model = Network(args.init_channels, CIFAR_CLASSES, args.layers, criterion)
    model.load_state_dict(torch.load(args.pretrain_path+'weights.pt'))
    arch_param = torch.load(args.pretrain_path+'alpha.pt')
    model.alphas_normal, model.alphas_reduce = arch_param[0], arch_param[1]
    # print()
    model = model.cuda()
    # 计算模型的参数,并写入log文件
    logging.info("param size = %fMB", utils.count_parameters_in_MB(model))

    print(model.alphas_normal)
    print(model.alphas_reduce)

    # validation
    valid_acc, valid_obj = infer(valid_queue, model, criterion)
    logging.info('valid_acc %f', valid_acc)



def infer(valid_queue, model, criterion):
    objs = utils.AvgrageMeter()
    top1 = utils.AvgrageMeter()
    top5 = utils.AvgrageMeter()
    model.eval()

    for step, (input, target) in enumerate(valid_queue):
        input = Variable(input, volatile=True).cuda()
        target = Variable(target, volatile=True).cuda()

        logits = model(input)
        loss = criterion(logits, target)

        prec1, prec5 = utils.accuracy(logits, target, topk=(1, 5))
        n = input.size(0)
        objs.update(loss.item(), n)
        top1.update(prec1.item(), n)
        top5.update(prec5.item(), n)

        if step % args.report_freq == 0:
            logging.info('valid %03d %e %f %f', step, objs.avg, top1.avg, top5.avg)
            # break

    return top1.avg, objs.avg


if __name__ == '__main__':
    train_transform, valid_transform = utils._data_transforms_cifar10(args)
    train_data = dset.CIFAR10(root=args.data, train=True, download=False, transform=train_transform)
    test_data = dset.CIFAR10(root=args.data, train=True, download=False, transform=valid_transform)

    num_train = len(train_data)
    indices = list(range(num_train))  # 50000的list[0,0...,0]
    split = int(np.floor(args.train_portion * num_train))  # 25000
    # 训练数据加载器，随机采样25000个训练数据
    train_queue = torch.utils.data.DataLoader(
        train_data, batch_size=args.batch_size,
        sampler=torch.utils.data.sampler.SubsetRandomSampler(indices[:split]),
        pin_memory=True, num_workers=0)
    # 　验证集数据加载器,随机采样25000个应征集数据从训练集里面
    valid_queue = torch.utils.data.DataLoader(
        test_data, batch_size=16,
        pin_memory=True, num_workers=0)
    main(train_queue, valid_queue)
