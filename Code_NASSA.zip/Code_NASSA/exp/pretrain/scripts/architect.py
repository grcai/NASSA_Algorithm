import torch
import numpy as np
import torch.nn as nn
from torch.autograd import Variable


def _concat(xs):
  return torch.cat([x.view(-1) for x in xs]) #　模型所有的数据会被变成１维


class Architect(object):
  # 设置的结构优化器为Adam优化器
  def __init__(self, model, args):
    self.network_momentum = args.momentum
    self.network_weight_decay = args.weight_decay
    self.model = model
    self.optimizer = torch.optim.Adam(self.model.arch_parameters(),
        lr=args.arch_learning_rate, betas=(0.5, 0.999), weight_decay=args.arch_weight_decay)

  def _compute_unrolled_model(self, input, target, eta, network_optimizer):
    # 在训练集上进行求损失函数
    loss = self.model._loss(input, target)
    # 网络模型的所有参数
    theta = _concat(self.model.parameters()).data  # size = [1930618]的tensor
    try:
      moment = _concat(network_optimizer.state[v]['momentum_buffer'] for v in self.model.parameters()).mul_(self.network_momentum)
    except:
      moment = torch.zeros_like(theta)   # 创建一个一维tensor大小为model的总参数大小 size = [1930618]
    dtheta = _concat(torch.autograd.grad(loss, self.model.parameters())).data + self.network_weight_decay*theta
    unrolled_model = self._construct_model_from_theta(theta.sub(eta, moment+dtheta))
    return unrolled_model

  def step(self, input_train, target_train, input_valid, target_valid, eta, network_optimizer, unrolled):
    self.optimizer.zero_grad()
    # 如果unrolled,则是要进行两步展开运算,一步在训练集上,一步在验证集上,否则只在验证集上
    if unrolled:
        self._backward_step_unrolled(input_train, target_train, input_valid, target_valid, eta, network_optimizer)
    else:
        self._backward_step(input_valid, target_valid)
    # 进行结构参数的优化
    self.optimizer.step()

  def _backward_step(self, input_valid, target_valid):
    loss = self.model._loss(input_valid, target_valid)
    loss.backward()

  def _backward_step_unrolled(self, input_train, target_train, input_valid, target_valid, eta, network_optimizer):
    # 使用Momentum优化方法在训练集上训练一遍, 得到一次优化的新模型
    unrolled_model = self._compute_unrolled_model(input_train, target_train, eta, network_optimizer)
    # 网络在验证集上计算损失函数
    unrolled_loss = unrolled_model._loss(input_valid, target_valid)
    # 损失反向传递
    unrolled_loss.backward()
    dalpha = [v.grad for v in unrolled_model.arch_parameters()]  # 结构参数的梯度, 2个(14,8)的tensor
    vector = [v.grad.data for v in unrolled_model.parameters()]  # 模型的参数梯度
    implicit_grads = self._hessian_vector_product(vector, input_train, target_train)  # 计算近似的二阶梯度,2个(14,8)的tensor

    for g, ig in zip(dalpha, implicit_grads):
      # 结构参数的一阶梯度减去二阶梯度
      g.data.sub_(eta, ig.data)
    # 将结构参数的梯度进行更新
    for v, g in zip(self.model.arch_parameters(), dalpha):
      if v.grad is None:
        v.grad = Variable(g.data)
      else:
        v.grad.data.copy_(g.data)

  def _construct_model_from_theta(self, theta):
    model_new = self.model.new()
    model_dict = self.model.state_dict()

    params, offset = {}, 0
    for k, v in self.model.named_parameters():
      v_length = np.prod(v.size())  # 计算所有元素的乘积
      params[k] = theta[offset: offset+v_length].view(v.size())
      offset += v_length

    assert offset == len(theta)  # 保证所有数据都写入params中
    model_dict.update(params)    # 更新模型参数
    model_new.load_state_dict(model_dict)  # 加载新的参数
    return model_new.cuda()      # 返回经过在训练集上训练了一遍后的模型,其模型的网络结构未变

  def _hessian_vector_product(self, vector, input, target, r=1e-2):
    # 计算近似二阶梯度
    R = r / _concat(vector).norm()   # .norm()求所有参数的均方值
    for p, v in zip(self.model.parameters(), vector):  # p是为优化前的一层模型参数,v是优化一次后的参数
      p.data.add_(R, v)
    loss = self.model._loss(input, target)
    grads_p = torch.autograd.grad(loss, self.model.arch_parameters())

    for p, v in zip(self.model.parameters(), vector):
      p.data.sub_(2*R, v)
    loss = self.model._loss(input, target)
    grads_n = torch.autograd.grad(loss, self.model.arch_parameters())
    # 将模型参数复原
    for p, v in zip(self.model.parameters(), vector):
      p.data.add_(R, v)

    return [(x-y).div_(2*R) for x, y in zip(grads_p, grads_n)]  # 返回两组,normal和reduce

