import torch
from torchvision.models import resnet18
from torch.autograd import Variable

model = resnet18().cuda()

# dummy inputs for the example
input = Variable(torch.randn(2,3,224,224).cuda(), requires_grad=True)
target = Variable(torch.zeros(2).long().cuda())
optimizer = torch.optim.SGD(
    model.parameters(),
    0.01,
    momentum=0.9,
    weight_decay=3e-4)
# as usual
output = model(input)
loss = torch.nn.functional.nll_loss(output, target)

grad_params = torch.autograd.grad(loss, model.parameters(), create_graph=True)
# torch.autograd.grad does not accumuate the gradients into the .grad attributes
# It instead returns the gradients as Variable tuples.

# now compute the 2-norm of the grad_params
grad_norm = 0
for grad in grad_params:
    grad_norm += grad.pow(2).sum()
grad_norm = grad_norm.sqrt()

# take the gradients wrt grad_norm. backward() will accumulate
# the gradients into the .grad attributes
grad_norm.backward()

# do an optimization step
optimizer.step()

# import torch
#
# x = torch.randn(3, 4).requires_grad_(True)
# for i in range(3):
#     for j in range(4):
#         x[i][j] = i + j
# y = x ** 2
# print(x)
# print(y)
# weight = torch.ones(y.size())
# print(weight)
# dydx = torch.autograd.grad(outputs=y,
#                            inputs=x,
#                            grad_outputs=weight,
#                            retain_graph=True,
#                            create_graph=True,
#                            only_inputs=True)
# """(x**2)' = 2*x """
# print('****',dydx[0])
# d2ydx2 = torch.autograd.grad(outputs=dydx[0],
#                              inputs=x,
#                              grad_outputs=weight,
#                              retain_graph=True,
#                              create_graph=True,
#                              only_inputs=True)
# print(d2ydx2[0])
