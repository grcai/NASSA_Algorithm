# NASSA
This is code for the algorithm "Saliency: A New Selection Criterion of Important Architectures in Neural Architecture Search".
Our source code is based on DARTS 
@article{liu2018darts,
  title={DARTS: Differentiable Architecture Search},
  author={Liu, Hanxiao and Simonyan, Karen and Yang, Yiming},
  journal={arXiv preprint arXiv:1806.09055},
  year={2018}
},
and its source is available at https://github.com/quark0/darts.
## Requirements
Python = 3.7, PyTorch == 1.8.1, torchvision == 0.9.1
## Datasets
Dataset can be downloaded here https://pan.baidu.com/s/1dEcb8szzb5pOUKcM5PsxBw, extraction code: wfy8.
To run code successfully, please unzip the dataset and place it in the current directory. 
## Train models
python pre_train.py --batch_size 64 --learing_rate 0.025 --epochs 50 --init_channels 16\
                    --layers 8 --seed 0
## Architecture search
python nassa_search.py --batch_size 32, --init_channels 16 --layers 8 --pretrain_path 'exp/pretrain/'
## Architecture evaluation
### On CIFAR10
python train_cifar.py --batch_size 64 --init_channels 36 --layers 15 --learning_rate 0.025\
                      --drop_path_prob 0.15  --arch 'NASSA' --data_name 'CIFAR10' --seed 0
### On CIFAR100
python train_cifar.py --batch_size 64 --init_channels 36 --layers 16 --learning_rate 0.025\
                      --drop_path_prob 0.15  --arch 'NASSA' --data_name 'CIFAR100' --seed 0
### On fashionMNIST
python train_fashionMNIST.py --batch_size 48 --init_channels 36 --layers 13 --epochs 300 --learning_rate 0.025\
                      --drop_path_prob 0.15   --arch 'NASSA'  --seed 0
### On Tiny-ImageNet
python train_tiny_imagenet.py --batch_size 48 --init_channels 48 --layers 14 --learning_rate 0.05\
                      --drop_path_prob 0.15   --arch 'NASSA'  --seed 0